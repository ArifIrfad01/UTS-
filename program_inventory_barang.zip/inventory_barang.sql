-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 07 Des 2021 pada 22.26
-- Versi server: 10.4.19-MariaDB
-- Versi PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_barang`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun`
--

CREATE TABLE `akun` (
  `username` varchar(30) NOT NULL,
  `password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `akun`
--

INSERT INTO `akun` (`username`, `password`) VALUES
('Arif Irfan Fadhillah', '19100106'),
('admin', 'admin'),
('Audina Honesty', '19100095');

-- --------------------------------------------------------

--
-- Struktur dari tabel `inventory_barang_keluar`
--

CREATE TABLE `inventory_barang_keluar` (
  `Kd_Barang` int(10) NOT NULL,
  `Nama_Barang` varchar(25) NOT NULL,
  `Tanggal_Masuk` date NOT NULL,
  `Tanggal_Keluar` date NOT NULL,
  `Jumlah` int(11) NOT NULL,
  `Kondisi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `inventory_barang_keluar`
--

INSERT INTO `inventory_barang_keluar` (`Kd_Barang`, `Nama_Barang`, `Tanggal_Masuk`, `Tanggal_Keluar`, `Jumlah`, `Kondisi`) VALUES
(2, 'Tas', '2021-12-12', '2021-12-20', 15, 'Baik'),
(3, 'Canvas', '2021-12-20', '2021-12-30', 5, 'Rusak Ringan'),
(4, 'Laptop', '2021-12-10', '2021-12-25', 10, 'Rusak Ringan'),
(3, 'Canvas', '2021-12-20', '2021-12-30', 5, 'Rusak Ringan');

--
-- Trigger `inventory_barang_keluar`
--
DELIMITER $$
CREATE TRIGGER `Keluar` AFTER INSERT ON `inventory_barang_keluar` FOR EACH ROW BEGIN
UPDATE inventory_barang_masuk SET Jumlah=Jumlah-NEW.Jumlah
WHERE Kd_Barang=NEW.Kd_Barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `inventory_barang_masuk`
--

CREATE TABLE `inventory_barang_masuk` (
  `Kd_Barang` int(10) NOT NULL,
  `Nama_Barang` varchar(25) NOT NULL,
  `Tanggal_Masuk` date NOT NULL,
  `Jumlah` int(10) NOT NULL,
  `Kondisi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `inventory_barang_masuk`
--

INSERT INTO `inventory_barang_masuk` (`Kd_Barang`, `Nama_Barang`, `Tanggal_Masuk`, `Jumlah`, `Kondisi`) VALUES
(1, 'Buku', '2021-12-10', 25, 'Baik'),
(2, 'Tas', '2021-12-12', 0, 'Baik'),
(3, 'Canvas', '2021-12-20', 20, 'Baik');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
